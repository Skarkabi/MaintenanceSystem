-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 192.168.6.102    Database: maintanence
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Sessions`
--

DROP TABLE IF EXISTS `Sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Sessions` (
  `sid` varchar(255) NOT NULL,
  `expires` datetime DEFAULT NULL,
  `data` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`sid`),
  KEY `session_sid_index` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sessions`
--

LOCK TABLES `Sessions` WRITE;
/*!40000 ALTER TABLE `Sessions` DISABLE KEYS */;
INSERT INTO `Sessions` VALUES ('2EEWdd4fiYdPpzVtrzTfsy2vlO1u24Hc','2021-06-13 11:11:43','{\"cookie\":{\"originalMaxAge\":7200000,\"expires\":\"2021-06-13T09:44:58.095Z\",\"httpOnly\":true,\"path\":\"/\"},\"passport\":{\"user\":100933847},\"flash\":{}}','2021-06-13 07:44:58','2021-06-13 09:11:43'),('f_KUDcdlN5dOKnobdXnlqJV3oD4FxBv0','2021-06-14 12:05:07','{\"cookie\":{\"originalMaxAge\":7200000,\"expires\":\"2021-06-14T12:05:07.872Z\",\"httpOnly\":true,\"path\":\"/\"},\"passport\":{\"user\":100933847},\"flash\":{}}','2021-06-14 07:45:53','2021-06-14 10:05:07'),('TEyccAnyqZCWdu4tbSom5BgCReddWFgH','2021-06-13 14:54:35','{\"cookie\":{\"originalMaxAge\":7200000,\"expires\":\"2021-06-13T14:53:51.997Z\",\"httpOnly\":true,\"path\":\"/\"},\"passport\":{\"user\":100933847},\"flash\":{}}','2021-06-13 10:07:25','2021-06-13 12:54:35'),('wdZ_s-HvGRoIgp_OefH46Z_KHKSbxbao','2021-06-14 07:14:00','{\"cookie\":{\"originalMaxAge\":7200000,\"expires\":\"2021-06-14T07:13:39.718Z\",\"httpOnly\":true,\"path\":\"/\"},\"passport\":{\"user\":100933847},\"flash\":{}}','2021-06-14 05:13:39','2021-06-14 05:14:00');
/*!40000 ALTER TABLE `Sessions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-14 14:09:52
